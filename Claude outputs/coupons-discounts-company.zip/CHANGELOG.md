# Coupons & Discounts per company: booking side — 2026-10-12

Only `app/controllers/pjAppController.controller.php` changed (price calculation). No SQL.

## Fixes
- **Coupon lookup** now uses only coupons of the property's company. It still requires the coupon to be linked to the property.
- **Coupon usage limit** ("Coupon code … reservations") counted confirmed bookings of every company that used the same code. It now counts only that company's bookings, so two companies can share a code without using up each other's limit.
- **Automatic discounts** are limited to the property's company (as well as being linked to the property).

The admin side (lists, add/edit/delete, export, property choices) was already per company.

## Tested on your XAMPP copy (Chrome, via Set company)
| | Hyatt | phpjabbers |
|---|---|---|
| Discounts list | HYATT20 only | PHPJABBERS10 only |
| Discount "Properties" choice | HYATT1 only | Calendar 1 only |
| Same coupon code TESTCO in both companies | allowed (10 $) | allowed (25 INR) |
| Booking form, TESTCO | 10.00 $ off | 25 INR off |
| Booking form, other company's code | refused | "Invalid promo code" |
| Opening/deleting the other company's discount or coupon by id | refused | refused |

The two TESTCO test coupons were deleted after the test.
