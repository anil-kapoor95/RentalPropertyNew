# Cron jobs per company — 2026-10-12

## Before
Both companies saw the same cron list (status, next run, last run, result). "Run now" ran the job for every company.

## Now
The cron URL and the job list stay shared: the server needs only one cron. Every company has its own:
- **On / off switch.** Click the Active / Inactive button in the Cron jobs list. It applies to the active company only.
- **Next run, last run and result.**
- **Run now:** runs the job for the active company only.

The server cron (`cron.php`) runs each job for every active company, on that company's own schedule. Companies that switched the job off are skipped.
- **Automatic back-ups:** one back-up per company, in that company's back-up list.
- **iCal import:** only that company's properties. The result lists the synced properties, e.g. "Calendar 2: OK | feeds:1 ...".
- A job switched off for the whole system (Inactive, no button) stays off for all companies.
- When the cron runs per company, it no longer makes the full system back-up. Make that one manually: Back-up > scope "System".

Banner: "These settings apply to company: X · The cron URL is the same for all companies. On/off, next run, last run and result are kept for this company only."

## Files
- **New:** `app/models/pjCompanyCron.model.php`
- `app/controllers/components/pjCompanyContext.component.php`
- `plugins/pjBase/controllers/pjBaseCron.controller.php`
- `plugins/pjBase/views/pjBaseCron/pjActionIndex.php`
- `plugins/pjBase/web/js/pjBaseCron.js`
- `plugins/pjBase/controllers/pjBaseBackup.controller.php`
- `app/controllers/pjCron.controller.php`
- `app/views/pjLayouts/elements/company-scope.php`
- `app/config/updates/update_2026_10_12_10_00_00.sql`: creates the table `companies_cron_jobs` (the code also creates it if missing) and updates the banner text.

## QA
Test copy, 3 companies, with an iCal URL on one property of Default and one of Acme:
- Default switched iCal off and ran Back-up now. Only Default's back-up folder got a new back-up. Acme's list was unchanged (N/A).
- Server cron run: Acme and Beta got back-ups. Default was skipped (not due yet).
- iCal: Default was skipped (off). Acme synced only "Calendar 2". Beta: 0 feeds. No system-wide back-up was made.

Your copy (Chrome):
- phpjabbers ran iCal import now and switched it off. Its row showed its own last/next run and result.
- Hyatt's row stayed "Active, N/A".
- phpjabbers' iCal import was switched back on afterwards.
