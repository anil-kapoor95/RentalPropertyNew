<?php
if (!defined("ROOT_PATH"))
{
	header("HTTP/1.1 403 Forbidden");
	exit;
}
class pjAdminCompanies extends pjAdmin
{
	const ROLE_COMPANY = 4;

	private $logoDir = 'companies/';

	/* ------------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Read and clean the posted company fields.
	 * $adminFields = false limits the result to the fields a Company user may edit.
	 */
	private function collectPostData($adminFields = true)
	{
		$text = array('name', 'legal_name', 'registration_no', 'tax_no', 'contact_person',
			'email', 'phone', 'website', 'address_1', 'address_2', 'city', 'state', 'zip');

		$data = array();
		foreach ($text as $f)
		{
			$v = trim((string) $this->_post->toString($f));
			$data[$f] = $v !== '' ? $v : ':NULL';
		}
		$data['country_id'] = $this->_post->toInt('country_id') > 0 ? $this->_post->toInt('country_id') : ':NULL';
		$desc = trim((string) $this->_post->toString('description'));
		$data['description'] = $desc !== '' ? $desc : ':NULL';

		if (!empty($data['website']) && $data['website'] !== ':NULL' && !preg_match('~^https?://~i', $data['website']))
		{
			$data['website'] = 'https://' . $data['website'];
		}

		if ($adminFields)
		{
			$data['status'] = $this->_post->check('status') ? 'T' : 'F';
			$data['user_id'] = $this->_post->toInt('user_id') > 0 ? $this->_post->toInt('user_id') : ':NULL';
			$commission = (float) $this->_post->toFloat('commission');
			$data['commission'] = max(0, min(100, round($commission, 2)));
			$notes = trim((string) $this->_post->toString('notes'));
			$data['notes'] = $notes !== '' ? $notes : ':NULL';
		}
		return $data;
	}

	/**
	 * Server-side validation. Returns an error label key or true.
	 */
	private function validateData($data, $company_id = 0)
	{
		// Required fields (also enforced in the form)
		foreach (array('name', 'contact_person', 'email', 'phone', 'address_1', 'city', 'country_id') as $f)
		{
			if (!isset($data[$f]) || $data[$f] === ':NULL' || $data[$f] === '' || $data[$f] === null)
			{
				return 'msgCompanyRequired';
			}
		}
		if ($data['email'] !== ':NULL' && !pjValidation::pjActionEmail($data['email']))
		{
			return 'msgCompanyError';
		}
		if ($data['website'] !== ':NULL' && !filter_var($data['website'], FILTER_VALIDATE_URL))
		{
			return 'msgCompanyError';
		}
		if (isset($data['user_id']) && $data['user_id'] !== ':NULL')
		{
			$user = pjAuthUserModel::factory()->find($data['user_id'])->getData();
			if (empty($user) || (int) $user['role_id'] !== self::ROLE_COMPANY)
			{
				return 'msgCompanyUserTaken';
			}
			$taken = pjCompanyModel::factory()
				->where('t1.user_id', $data['user_id'])
				->where('t1.id !=', (int) $company_id)
				->findCount()->getData();
			if ((int) $taken > 0)
			{
				return 'msgCompanyUserTaken';
			}
		}
		return true;
	}

	/**
	 * Handle the logo upload / removal. Returns the new relative path, the old one,
	 * ':NULL' when removed, or false when an upload was attempted and failed.
	 */
	private function handleLogo($company_id, $current = null)
	{
		$remove = $this->_post->check('remove_logo');
		$hasUpload = isset($_FILES['logo']) && !empty($_FILES['logo']['name']) && $_FILES['logo']['error'] !== UPLOAD_ERR_NO_FILE;

		if (!$hasUpload)
		{
			if ($remove && !empty($current))
			{
				$this->deleteLogoFile($current);
				return ':NULL';
			}
			return $current;
		}

		$dir = PJ_UPLOAD_PATH . $this->logoDir;
		if (!is_dir($dir))
		{
			@mkdir($dir, 0755, true);
			@file_put_contents($dir . 'index.php', '<?php header("HTTP/1.1 403 Forbidden"); exit; ?>');
		}

		$handle = new pjUpload();
		$handle->setAllowedExt(array('jpg', 'jpeg', 'png', 'gif', 'webp'));
		$handle->setAllowedTypes(array(
			'image/jpeg', 'image/jpg', 'image/pjpeg',
			'image/png', 'image/x-png', 'image/gif', 'image/webp'
		));
		if (!$handle->load($_FILES['logo']))
		{
			return false;
		}
		$ext = strtolower($handle->getExtension());
		$path = $dir . (int) $company_id . '_' . md5(uniqid(rand(), true)) . '.' . $ext;
		if (!$handle->save($path))
		{
			return false;
		}
		if (@getimagesize($path) === false)
		{
			@unlink($path);
			return false;
		}
		if (!empty($current))
		{
			$this->deleteLogoFile($current);
		}
		return $path;
	}

	private function deleteLogoFile($path)
	{
		// Only ever delete files inside our own upload folder.
		if (!empty($path) && strpos($path, PJ_UPLOAD_PATH . $this->logoDir) === 0 && strpos($path, '..') === false && is_file($path))
		{
			@unlink($path);
		}
	}

	private function setFormData($company_id = 0)
	{
		$this->set('country_arr', pjBaseCountryModel::factory()
			->select('t1.id, t2.content AS name')
			->join('pjMultiLang', "t2.model='pjBaseCountry' AND t2.foreign_id=t1.id AND t2.field='name' AND t2.locale='".$this->getLocaleId()."'", 'left outer')
			->where('t1.status', 'T')
			->orderBy('`name` ASC')->findAll()->getData()
		);

		// Company-role users that are free (or already linked to this company)
		$company_table = pjCompanyModel::factory()->getTable();
		$this->set('user_arr', pjAuthUserModel::factory()
			->select('t1.id, t1.name, t1.email')
			->where('t1.role_id', self::ROLE_COMPANY)
			->where(sprintf("t1.id NOT IN (SELECT `user_id` FROM `%s` WHERE `user_id` IS NOT NULL AND `id` != %u)", $company_table, (int) $company_id))
			->orderBy('t1.name ASC')->findAll()->getData()
		);
	}

	private function appendFormAssets()
	{
		$this->appendCss('css/select2.min.css', PJ_THIRD_PARTY_PATH . 'select2/');
		$this->appendJs('js/select2.full.min.js', PJ_THIRD_PARTY_PATH . 'select2/');
		$this->appendJs('pjAdminCompanies.js');
	}

	/* ------------------------------------------------------------------
	 * Actions
	 * ------------------------------------------------------------------ */

	public function pjActionIndex()
	{
		$this->checkLogin();
		if (!pjAuth::factory()->hasAccess())
		{
			$this->sendForbidden();
			return;
		}
		$this->set('has_update', pjAuth::factory('pjAdminCompanies', 'pjActionUpdate')->hasAccess());
		$this->set('has_create', pjAuth::factory('pjAdminCompanies', 'pjActionCreate')->hasAccess());
		$this->set('has_delete', pjAuth::factory('pjAdminCompanies', 'pjActionDeleteCompany')->hasAccess());
		$this->set('has_delete_bulk', pjAuth::factory('pjAdminCompanies', 'pjActionDeleteCompanyBulk')->hasAccess());

		$this->appendJs('jquery.datagrid.js', PJ_FRAMEWORK_LIBS_PATH . 'pj/js/');
		$this->appendJs('pjAdminCompanies.js');
	}

	public function pjActionGetCompany()
	{
		$this->setAjax(true);
		if (!$this->isXHR())
		{
			exit;
		}

		$pjCompanyModel = pjCompanyModel::factory()
			->join('pjAuthUser', 't2.id=t1.user_id', 'left outer');

		if ($q = $this->_get->toString('q'))
		{
			$q = str_replace(array('_', '%'), array('\_', '\%'), $pjCompanyModel->escapeStr($q));
			$pjCompanyModel->where(sprintf("(t1.name LIKE '%%%1\$s%%' OR t1.legal_name LIKE '%%%1\$s%%' OR t1.email LIKE '%%%1\$s%%' OR t1.phone LIKE '%%%1\$s%%' OR t1.registration_no LIKE '%%%1\$s%%' OR t1.city LIKE '%%%1\$s%%')", $q));
		}
		if ($this->_get->check('status') && in_array($this->_get->toString('status'), array('T', 'F')))
		{
			$pjCompanyModel->where('t1.status', $this->_get->toString('status'));
		}

		$column = 'name';
		$direction = 'ASC';
		$allowed_columns = array('name', 'email', 'phone', 'city', 'status', 'created');
		if ($this->_get->toString('column') && in_array($this->_get->toString('column'), $allowed_columns) && in_array(strtoupper($this->_get->toString('direction')), array('ASC', 'DESC')))
		{
			$column = $this->_get->toString('column');
			$direction = strtoupper($this->_get->toString('direction'));
		}

		$total = $pjCompanyModel->findCount()->getData();
		$rowCount = $this->_get->toInt('rowCount') ? $this->_get->toInt('rowCount') : 10;
		$pages = ceil($total / $rowCount);
		$page = $this->_get->toInt('page') ? $this->_get->toInt('page') : 1;
		$offset = ((int) $page - 1) * $rowCount;
		if ($page > $pages)
		{
			$page = $pages;
		}

		$data = $pjCompanyModel
			->select('t1.id, t1.name, t1.email, t1.phone, t1.city, t1.status, t1.created, t2.name AS user_name')
			->orderBy("t1.$column $direction")
			->limit($rowCount, $offset)
			->findAll()
			->getData();

		foreach ($data as $k => $v)
		{
			$data[$k]['name'] = pjSanitize::clean($v['name']);
			$data[$k]['email'] = pjSanitize::clean((string) $v['email']);
			$data[$k]['phone'] = pjSanitize::clean((string) $v['phone']);
			$data[$k]['city'] = pjSanitize::clean((string) $v['city']);
			$data[$k]['user_name'] = !empty($v['user_name']) ? pjSanitize::clean($v['user_name']) : '—';
		}

		pjAppController::jsonResponse(compact('data', 'total', 'pages', 'page', 'rowCount', 'column', 'direction'));
	}

	public function pjActionCreate()
	{
		$this->checkLogin();
		if (!pjAuth::factory()->hasAccess())
		{
			$this->sendForbidden();
			return;
		}

		if (self::isPost() && $this->_post->check('company_create'))
		{
			$data = $this->collectPostData(true);
			$valid = $this->validateData($data, 0);
			if ($valid !== true)
			{
				pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionCreate&msg=" . $valid);
			}

			$id = pjCompanyModel::factory()->setAttributes($data)->insert()->getInsertId();
			if ($id === false || (int) $id <= 0)
			{
				pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionCreate&msg=msgCompanyError");
			}

			$msg = 'msgCompanyAdded';
			$logo = $this->handleLogo($id, null);
			if ($logo === false)
			{
				$msg = 'msgCompanyInvalidLogo';
			} elseif (!empty($logo) && $logo !== ':NULL') {
				pjCompanyModel::factory()->set('id', $id)->modify(array('logo' => $logo));
			}
			pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionUpdate&id=" . (int) $id . "&msg=" . $msg);
		}

		$this->setFormData(0);
		$this->appendFormAssets();
	}

	public function pjActionUpdate()
	{
		$this->checkLogin();
		if (!pjAuth::factory()->hasAccess())
		{
			$this->sendForbidden();
			return;
		}

		if (self::isPost() && $this->_post->check('company_update'))
		{
			$id = $this->_post->toInt('id');
			$arr = pjCompanyModel::factory()->find($id)->getData();
			if (empty($arr))
			{
				pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionIndex&msg=msgCompanyNotFound");
			}

			$data = $this->collectPostData(true);
			$valid = $this->validateData($data, $id);
			if ($valid !== true)
			{
				pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionUpdate&id=$id&msg=" . $valid);
			}

			$msg = 'msgCompanySaved';
			$logo = $this->handleLogo($id, $arr['logo']);
			if ($logo === false)
			{
				$msg = 'msgCompanyInvalidLogo';
			} else {
				$data['logo'] = empty($logo) ? ':NULL' : $logo;
			}
			$data['modified'] = date('Y-m-d H:i:s');
			pjCompanyModel::factory()->set('id', $id)->modify($data);
			pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionUpdate&id=$id&msg=" . $msg);
		}

		$arr = pjCompanyModel::factory()->find($this->_get->toInt('id'))->getData();
		if (empty($arr))
		{
			pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionIndex&msg=msgCompanyNotFound");
		}
		$this->set('arr', $arr);
		$this->setFormData($arr['id']);
		$this->appendFormAssets();
	}

	/**
	 * "My company" page for users with the Company role.
	 */
	public function pjActionProfile()
	{
		$this->checkLogin();
		if (!pjAuth::factory()->hasAccess())
		{
			$this->sendForbidden();
			return;
		}

		$arr = pjCompanyModel::factory()->where('t1.user_id', $this->getUserId())->limit(1)->findAll()->getDataIndex(0);

		if (self::isPost() && $this->_post->check('company_profile'))
		{
			if (empty($arr))
			{
				pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionProfile");
			}
			$data = $this->collectPostData(false);
			$data = array_intersect_key($data, array_flip(pjCompanyModel::$profileFields));
			$valid = $this->validateData($data, $arr['id']);
			if ($valid !== true)
			{
				pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionProfile&msg=" . $valid);
			}
			$msg = 'msgCompanySaved';
			$logo = $this->handleLogo($arr['id'], $arr['logo']);
			if ($logo === false)
			{
				$msg = 'msgCompanyInvalidLogo';
			} else {
				$data['logo'] = empty($logo) ? ':NULL' : $logo;
			}
			$data['modified'] = date('Y-m-d H:i:s');
			pjCompanyModel::factory()->set('id', $arr['id'])->modify($data);
			pjUtil::redirect($_SERVER['PHP_SELF'] . "?controller=pjAdminCompanies&action=pjActionProfile&msg=" . $msg);
		}

		$this->set('arr', !empty($arr) ? $arr : false);
		if (!empty($arr))
		{
			$this->setFormData($arr['id']);
			$this->appendFormAssets();
		}
	}

	/**
	 * Inline grid edit. Only whitelisted columns can be changed.
	 */
	public function pjActionSaveCompany()
	{
		$this->setAjax(true);
		if (!$this->isXHR())
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 100, 'text' => 'Missing headers.'));
		}
		if (!self::isPost())
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 101, 'text' => 'HTTP method not allowed.'));
		}
		$id = $this->_get->toInt('id');
		$column = $this->_post->toString('column');
		$value = trim((string) $this->_post->toString('value'));

		if ($id <= 0 || !in_array($column, array('name', 'status'), true))
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 102, 'text' => 'Missing, empty or invalid parameters.'));
		}
		if ($column === 'status' && !in_array($value, array('T', 'F'), true))
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 102, 'text' => 'Invalid status.'));
		}
		if ($column === 'name' && $value === '')
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 102, 'text' => 'Name is required.'));
		}
		pjCompanyModel::factory()->where('id', $id)->limit(1)->modifyAll(array($column => $value, 'modified' => date('Y-m-d H:i:s')));
		self::jsonResponse(array('status' => 'OK', 'code' => 200));
	}

	public function pjActionDeleteCompany()
	{
		$this->setAjax(true);
		if (!$this->isXHR())
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 100, 'text' => 'Missing headers.'));
		}
		$id = $this->_get->toInt('id');
		if ($id <= 0)
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 101, 'text' => 'Missing, empty or invalid parameters.'));
		}
		$arr = pjCompanyModel::factory()->find($id)->getData();
		if (!empty($arr) && pjCompanyModel::factory()->set('id', $id)->erase()->getAffectedRows() == 1)
		{
			// The linked user account is kept; it simply has no company any more.
			$this->deleteLogoFile($arr['logo']);
			self::jsonResponse(array('status' => 'OK'));
		}
		self::jsonResponse(array('status' => 'ERR'));
	}

	public function pjActionDeleteCompanyBulk()
	{
		$this->setAjax(true);
		if (!$this->isXHR())
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 100, 'text' => 'Missing headers.'));
		}
		if (!self::isPost())
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 101, 'text' => 'HTTP method not allowed.'));
		}
		if (!$this->_post->has('record') || !($record = $this->_post->toArray('record')))
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 102, 'text' => 'Missing, empty or invalid data.'));
		}
		$record = array_values(array_filter(array_map('intval', $record)));
		if (empty($record))
		{
			self::jsonResponse(array('status' => 'ERR', 'code' => 102, 'text' => 'Missing, empty or invalid data.'));
		}
		$logos = pjCompanyModel::factory()->whereIn('id', $record)->findAll()->getDataPair('id', 'logo');
		if (pjCompanyModel::factory()->whereIn('id', $record)->eraseAll()->getAffectedRows() > 0)
		{
			foreach ($logos as $logo)
			{
				$this->deleteLogoFile($logo);
			}
			self::jsonResponse(array('status' => 'OK'));
		}
		self::jsonResponse(array('status' => 'ERR'));
	}
}
?>
